# My DataScience Projects


## Проекты

* [Проект 0. Игра: Угадай число за минимальное кол-во попыток](https://github.com/Talic13th/SGlearning/tree/main/project_0)
* [Проект 1. Анализ резюме на hh.ru](https://github.com/Talic13th/SGlearning/tree/main/project_1)